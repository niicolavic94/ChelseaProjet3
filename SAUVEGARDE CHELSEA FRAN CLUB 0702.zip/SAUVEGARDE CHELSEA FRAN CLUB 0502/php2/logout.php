<?php
session_start();

// Vérifiez si une session est active
if (isset($_SESSION['user_id'])) {
    // Supprime toutes les variables de session
    session_unset(); 
    // Détruit la session
    session_destroy(); 
    // Redirige vers la page de connexion avec un message
    header("Location: connexion.php?message=deconnexion");
    exit();
} else {
    // Si aucune session n'est active, redirigez simplement vers la page de connexion
    header("Location: connexion.php");
    exit();
}
?>