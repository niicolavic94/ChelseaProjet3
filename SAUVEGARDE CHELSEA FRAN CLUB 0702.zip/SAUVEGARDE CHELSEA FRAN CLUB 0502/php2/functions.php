<?php
function sendEmail($to, $subject, $message) {
    // Utilisez une bibliothèque comme PHPMailer pour une meilleure gestion des emails
    mail($to, $subject, $message);
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function validatePassword($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
}
?>