<?php
session_start();

// Configuration de la base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'chelsea_club');
define('DB_USER', 'root');
define('DB_PASS', '');

function cleanInput($data) {
    return htmlspecialchars(trim($data));
}

if (isset($_GET['token'])) {
    $token = cleanInput($_GET['token']);

    try {
        // Connexion à la base de données
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Vérifiez le token
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE verification_token = :token");
        $stmt->execute(['token' => $token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Marquer l'email comme vérifié
            $stmt = $pdo->prepare("UPDATE utilisateurs SET email_verified = 1 WHERE id = :id");
            $stmt->execute(['id' => $user['id']]);
            $_SESSION['message'] = "Votre email a été vérifié avec succès.";
        } else {
            $_SESSION['message'] = "Token invalide. Veuillez vérifier votre lien de vérification.";
        }
    } catch (PDOException $e) {
        // Gestion des erreurs
        $_SESSION['message'] = "Erreur de connexion à la base de données. Veuillez réessayer plus tard.";
        error_log("Erreur de connexion : " . $e->getMessage()); // Journaliser l'erreur pour le débogage
    }
} else {
    $_SESSION['message'] = "Aucun token fourni. Veuillez vérifier votre lien de vérification.";
}

// Rediriger vers la page de connexion
header("Location: connexion.php");
exit();
?>