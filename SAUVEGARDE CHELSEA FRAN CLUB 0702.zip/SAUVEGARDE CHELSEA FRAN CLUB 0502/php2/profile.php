<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

// Connexion à la base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'chelsea_club');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = :id");
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception("Utilisateur non trouvé.");
    }
} catch (PDOException $e) {
    error_log($e->getMessage()); // Enregistrer l'erreur dans un fichier de log
    echo "Une erreur est survenue. Veuillez réessayer plus tard.";
    exit();
} catch (Exception $e) {
    echo "Une erreur est survenue : " . htmlspecialchars($e->getMessage());
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Profil - Chelsea Fran Club</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Profil de <?php echo htmlspecialchars($user['username']); ?></h1>
        <p>Email : <?php echo htmlspecialchars($user['email']); ?></p>
        <p>Date d'inscription : <?php echo htmlspecialchars($user['date_inscription']); ?></p>
        <a href="logout.php" class="btn btn-danger">Déconnexion</a>
        <a href="edit_profile.php" class="btn btn-primary">Modifier le profil</a>
    </div>
</body>
</html>