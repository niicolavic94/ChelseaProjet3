<?php
session_start();
$host = 'localhost';
$db = 'chelsea_club';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // CSRF Token
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Vérification du token CSRF
        if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            die("Invalid CSRF token");
        }

        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        // Validation
        if (empty($username) || empty($email) || empty($password)) {
            $_SESSION['message'] = "Tous les champs sont requis.";
            header("Location: inscription.html");
            exit();
        }

        // Validation de l'email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['message'] = "L'email n'est pas valide.";
            header("Location: inscription.html");
            exit();
        }

        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE username = :username OR email = :email");
        $stmt->execute(['username' => $username, 'email' => $email]);
        if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = "Cet utilisateur ou cet email existe déjà.";
            header("Location: inscription.html");
            exit();
        } else {
            $stmt = $pdo->prepare("INSERT INTO utilisateurs (username, email, password) VALUES (:username, :email, :password)");
            $stmt->execute(['username' => $username, 'email' => $email, 'password' => $password]);
            $_SESSION['message'] = "Inscription réussie. Vous pouvez maintenant vous connecter.";
            header("Location: connexion.html");
            exit();
        }
    }
} catch (PDOException $e) {
    echo "Erreur de connexion : " . htmlspecialchars($e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Histoire du Chelsea Fran Club.">
    <meta name="keywords" content="Chelsea, FC, football, histoire, communauté">
    <meta name="author" content="Chelsea Fran Club">
    <title>Inscription - Chelsea Fran Club</title>
    <link rel="stylesheet" href="/style/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <a href="accueil.html">
                <img src="../images CLUB/Logos/LOGO_DU_SITE-removebg-preview - Copie.png" alt="Logo Chelsea Fran Club">
            </a>
        </div>
        <h1>Chelsea Fran Club</h1>    
        <div class="auth-buttons">
            <a href="connexion.html">Se connecter</a>
            <a href="inscription.html">S'inscrire</a>
        </div>
    </header>
    
    <nav>
        <ul>
            <li><a href="accueilv2.html">Accueil</a></li>
            <li><a href="actu2.html">Actualités</a></li>
            <li><a href="match.html">Match</a></li>
            <li>
                <a href="#">Club</a>
                <ul class="dropdown">
                    <li><a href="histoire.html">Notre Histoire</a></li>
                    <li><a href="statistiques.html">Statistiques</a></li>
                    <li><a href="effectif.html">Effectif</a></li>
                    <li><a href="classement.html">Saison 24/25</a></li>
                </ul>
            </li>
            <li><a href="compte.html">Compte</a></li>
        </ul>
    </nav>

    <main>
        <h2>Inscription</h2>
        <div class="form-container">
            <form id="registrationForm" method="POST" action="">
                <input type="text" name="username" id="username" placeholder="Nom d'utilisateur" required>
                <input type="email" name="email" id="email" placeholder="Email" required>
                <input type="password" name="password" id="password" placeholder="Mot de passe" required>
                <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirmer le mot de passe" required>
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <button type="submit">S'inscrire</button>
                <p style="margin-top: 30px; font-size: 16px; color:black;">
                    Déjà inscrit ? <a href="connexion.html" style="color:whitesmoke; text-decoration: none; font-size: 15px;">Connecte toi ici</a>
                </p>
            </form>
            <div class="message" id="message">
                <?php
                if (isset($_SESSION['message'])) {
                    echo $_SESSION['message'];
                    unset($_SESSION['message']); // Supprimer le message après l'affichage
                }
                ?>
            </div>
        </div>
    </main>
    
    <footer>
        <div class="footer-links">
            <a href="mentionslegales.html">Mentions légales</a>
            <a href="faq.html">Foire à questions</a>
        </div>
    </footer>

    <script>
    const form = document.getElementById('registrationForm');
    const messageDiv = document.getElementById('message');

    form.addEventListener('submit', function(event) {
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        // Regex pour valider l'email (plus robuste)
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        // Regex pour valider le mot de passe (au moins 8 caractères, une lettre majuscule, une lettre minuscule, un chiffre et un caractère spécial)
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        // Regex pour valider le nom d'utilisateur (alphanumérique, 3 à 20 caractères)
        const usernameRegex = /^[a-zA-Z0-9]{3,20}$/;

        if (!usernameRegex.test(username)) {
            messageDiv.textContent = "Le nom d'utilisateur doit contenir entre 3 et 20 caractères alphanumériques.";
            messageDiv.classList.add('error');
            event.preventDefault();
            return;
        }

        if (!emailRegex.test(email)) {
            messageDiv.textContent = "L'email n'est pas valide.";
            messageDiv.classList.add('error');
            event.preventDefault();
            return;
        }

        if (!passwordRegex.test(password)) {
            messageDiv.textContent = "Le mot de passe doit contenir au moins 8 caractères, une lettre majuscule, une lettre minuscule, un chiffre et un caractère spécial.";
            messageDiv.classList.add('error');
            event.preventDefault();
            return;
        }

        if (password !== confirmPassword) {
            messageDiv.textContent = "Les mots de passe ne correspondent pas.";
            messageDiv.classList.add('error');
            event.preventDefault();
            return;
        }

        messageDiv.textContent = "Inscription réussie !";
        messageDiv.classList.remove('error');
        messageDiv.classList.add('success');
    });

    </script>
</body>
</html>