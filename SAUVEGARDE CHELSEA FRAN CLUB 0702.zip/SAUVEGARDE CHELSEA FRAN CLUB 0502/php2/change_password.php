<?php
session_start();
$host = 'localhost';
$db = 'chelsea_club';
$user = 'root';
$pass = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['new_password'];
    $token = $_POST['token'];

    // Validation du mot de passe
    if (strlen($newPassword) < 8 || !preg_match('/[A-Z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
        $_SESSION['error'] = "Le mot de passe doit contenir au moins 8 caractères, une majuscule et un chiffre.";
        header("Location: " . $_SERVER['PHP_SELF'] . "?token=" . urlencode($token));
        exit();
    }

    $newPasswordHashed = password_hash($newPassword, PASSWORD_DEFAULT);

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Mettre à jour le mot de passe
        $stmt = $pdo->prepare("UPDATE utilisateurs SET password = :password, reset_token = NULL WHERE reset_token = :token");
        $stmt->execute(['password' => $newPasswordHashed, 'token' => $token]);

        $_SESSION['message'] = "Votre mot de passe a été changé avec succès.";
        header("Location: connexion.php");
        exit();
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur de connexion : " . htmlspecialchars($e->getMessage());
        header("Location: " . $_SERVER['PHP_SELF'] . "?token=" . urlencode($token));
        exit();
    }
}

if (isset($_GET['token'])) {
    $token = $_GET['token'];
} else {
    die("Token manquant.");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Changer le mot de passe</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input[type="password"], button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #4cae4c;
        }
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>
    <h2>Changer le mot de passe</h2>
    <form method="POST" action="">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
        <input type="password" name="new_password" placeholder="Nouveau mot de passe" required>
        <button type="submit">Changer le mot de passe</button>
    </form>
    <div>
        <?php
        if (isset($_SESSION['message'])) {
            echo "<div class='success'>" . $_SESSION['message'] . "</div>";
            unset($_SESSION['message']);
        }
        if (isset($_SESSION['error'])) {
            echo "<div class='error'>" . $_SESSION['error'] . "</div>";
            unset($_SESSION['error']);
        }
        ?>
    </div>
</body>
</html>