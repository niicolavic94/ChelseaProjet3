<?php
// Fichier de configuration pour la connexion à la base de données
define('DB_HOST', 'localhost');
define('DB_NAME', 'chelsea_club');
define('DB_USER', 'root');
define('DB_PASS', '');

class Database {
    private $pdo;

    public function __construct() {
        $this->connect();
    }

    private function connect() {
        try {
            $this->pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            $this->logError($e);
            die("Erreur de connexion à la base de données.");
        }
    }

    private function logError(PDOException $e) {
        // Enregistrer l'erreur dans un fichier de log
        file_put_contents('db_errors.log', date('Y-m-d H:i:s') . " - " . $e->getMessage() . PHP_EOL, FILE_APPEND);
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Utilisation de la classe Database
$db = new Database();
$pdo = $db->getConnection();
?>